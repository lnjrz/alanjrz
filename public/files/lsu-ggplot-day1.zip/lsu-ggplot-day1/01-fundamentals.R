################################################################################
#                          LS Uppsala DataViz Course                           #
#  "Data Visualization with ggplot2: Fundamentals of the Grammar of Graphics"  #
#                     Cédric Scherer | November 26, 2026                       #
################################################################################


## To run all codes, install the typeface Sofia Sans Semi Condensed and 
## restart RStudio. The font files are located in the `fonts` folder. 

## Also, make sure to install the following packages:
packages <- c(
  "ggplot2", "readr", "dplyr", "forcats", "stringr", "scales", 
  "ragg", "systemfonts", "RColorBrewer"
)

install.packages(setdiff(packages, rownames(installed.packages())))


## -----------------------------------------------------------------------------
# install.packages("ggplot2")
library(ggplot2)

# install.packages("tidyverse")
# library(tidyverse)


## -----------------------------------------------------------------------------
bikes <- 
  readr::read_csv(
    "https://cedricscherer.com/data/london-bikes.csv",
    col_types = "Dcfffilllddddc"
  ) |> 
  dplyr::filter(!is.na(weather_type))


## -----------------------------------------------------------------------------
?ggplot


## -----------------------------------------------------------------------------
ggplot(data = bikes)


## -----------------------------------------------------------------------------
ggplot(data = bikes) +
  aes(x = temp_feel, y = n)


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  mapping = aes(x = temp_feel, y = n)
)


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
)


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    size = 4,
    shape = "X",
    color = "#28a87d",
    alpha = .5,
    stroke = 1
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    size = 4,
    shape = 23,
    color = "white",
    fill = "#28a87d",
    alpha = .5,
    stroke = 1
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    color = "#28a87d",
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    aes(color = season),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    aes(color = temp_feel > 20),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    aes(color = season),
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season)
) +
  geom_point(
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season)
) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season)
) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    method = "lm"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n)
) +
  geom_point(
    aes(color = season),
    alpha = .5
  ) +
  geom_smooth(
    aes(group = day_night),
    method = "lm"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season,
      group = day_night)
) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season,
      group = day_night)
) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )


## -----------------------------------------------------------------------------
g <-
  ggplot(
    bikes,
    aes(x = temp_feel, y = n,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )


## -----------------------------------------------------------------------------
g <-
  ggplot(
    bikes,
    aes(x = temp_feel, y = n,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  )

class(g)


## -----------------------------------------------------------------------------
g +
  geom_rug(
    alpha = .2
  )


## -----------------------------------------------------------------------------
g +
  geom_rug(
    alpha = .2,
    show.legend = FALSE
  )


## -----------------------------------------------------------------------------
ggplot(
  data = filter(bikes, day_night == "day"),
  aes(x = date, y = humidity)
) +
  geom_line()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = date, y = humidity,
      color = day_night)
) +
  geom_line()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = humidity)
) +
  geom_histogram()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = humidity)
) +
  geom_density()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = humidity)
) +
  geom_density(
    aes(color = season)
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = humidity)
) +
  geom_density(
    aes(fill = season),
    position = "stack"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season)
) +
  geom_bar()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n)
) +
  geom_col()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n,
      fill = day_night)
) +
  geom_col()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n,
      fill = day_night)
) +
  geom_col(
    position = "dodge"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n,
      fill = day_night)
) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n,
      color = day_night)
) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, 
      y = n,
      color = day_night)
) +
  geom_jitter(
    alpha = .3
  )


## -----------------------------------------------------------------------------
g +
  facet_wrap(
    facets = vars(day_night)
  )


## -----------------------------------------------------------------------------
g +
  facet_wrap(
    ~ day_night
  )


## -----------------------------------------------------------------------------
g +
  facet_wrap(
    ~ season + day_night
  )


## -----------------------------------------------------------------------------
g +
  facet_wrap(
    ~ season + day_night,
    ncol = 2
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    rows = vars(season),
    cols = vars(day_night)
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    season ~ day_night
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    day_night ~ is_workday
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free"
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free",
    space = "free"
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y",
    space = "free_y"
  )


## -----------------------------------------------------------------------------
g +
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y",
    space = "free_y",
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = c(
        `TRUE` = "Workday",
        `FALSE` = "Weekend or Holiday"
      )
    )
  )


## -----------------------------------------------------------------------------
g +
  coord_cartesian()


## -----------------------------------------------------------------------------
g +
  coord_cartesian(
    expand = FALSE
  )


## -----------------------------------------------------------------------------
g +
  coord_cartesian(
    expand = FALSE,
    clip = "off"
  )


## -----------------------------------------------------------------------------
g +
  coord_cartesian(
    expand = FALSE,
    clip = "off",
    ylim = c(NA, 17500)
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = temp)
) +
  geom_point() +
  coord_fixed()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = temp)
) +
  geom_point() +
  coord_fixed(ratio = 4)


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_cartesian()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_flip()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(y = weather_type)
) +
  geom_bar() +
  coord_cartesian()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_flip()


## -----------------------------------------------------------------------------
library(forcats)

ggplot(
  bikes,
  aes(y = fct_infreq(weather_type))
) +
  geom_bar()


## -----------------------------------------------------------------------------
library(forcats)

ggplot(
  bikes,
  aes(y = fct_rev(fct_infreq(weather_type)))
) +
  geom_bar()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = temp)
) +
  geom_point() +
  coord_polar()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = temp)
) +
  geom_point() +
  coord_radial()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_polar()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_radial()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_polar(theta = "y")


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = weather_type)
) +
  geom_bar() +
  coord_radial(theta = "y")


## -----------------------------------------------------------------------------
g +
  coord_radial(
    theta = "y", 
    r.axis.inside = TRUE
  )


## -----------------------------------------------------------------------------
g +
  coord_radial(
    theta = "y", 
    r.axis.inside = TRUE,
    inner.radius = .3
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = date, y = n)
) +
  geom_point() +
  coord_trans(
    y = "log10"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = date, y = n)
) +
  geom_point() +
  coord_trans(
    y = "sqrt"
  )


## -----------------------------------------------------------------------------
g +
  labs(
    x = "Feels-like temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends"
  )


## -----------------------------------------------------------------------------
g <- g +
  labs(
    x = "Feels-like temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    color = NULL
  )

g


## -----------------------------------------------------------------------------
g +
  labs(
    subtitle = "Reported bike rents vs feels-like temperature",
    caption = "Data: TfL",
    tag = "Fig. 1",
    color = "Season:"
  )


## -----------------------------------------------------------------------------
g +
  labs(
    x = "",
    caption = "Data: TfL"
  )


## -----------------------------------------------------------------------------
g +
  labs(
    x = NULL,
    caption = "Data: TfL"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = temp_feel, y = n,
      color = season)
) +
  geom_point() +
  scale_x_continuous() +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
ggplot(
  bikes,
  aes(x = season, y = temp_feel)
) +
  geom_boxplot() +
  scale_x_discrete() +
  scale_y_continuous()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous() +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_binned() +
  scale_y_log10() +
  scale_color_viridis_d()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = c(.05, 0)
  ) +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05)
  ) +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5)
  ) +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C")
  ) +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous() +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500))
  ) +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA)
  ) +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(5000, 20000)
  ) +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_discrete()


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_discrete(
    type = c("#3c89d9", "#1ec99b", "#f7b01b", "#a26e7c")
  )


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#f7b01b", "#a26e7c")
  )


## -----------------------------------------------------------------------------
season_colors <- c(
  `autumn` = "#a26e7c",
  `spring` = "#1ec99b",
  `summer` = "#f7b01b",
  `winter` = "#3c89d9"
)

g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = c(mult = 0, add = 1500),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = season_colors
  )


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_brewer(
    palette = "Dark2"
  )


## -----------------------------------------------------------------------------
RColorBrewer::display.brewer.all()


## -----------------------------------------------------------------------------
RColorBrewer::display.brewer.all(colorblindFriendly = TRUE)


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  aes(x = temp_feel, y = n,
      color = humidity)
) +
  geom_point(
    alpha = .5
  )


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  aes(x = temp_feel, y = n,
      color = humidity)
) +
  geom_point(
    alpha = .5
  ) +
  scale_color_distiller(
    palette = "GnBu",
    direction = 1
  )


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  aes(x = temp_feel, y = n,
      color = humidity)
) +
  geom_point(
    alpha = .5
  ) +
  scale_color_viridis_c(
    direction = -1,
    end = .9
  )


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  aes(x = temp_feel, y = n,
      color = humidity)
) +
  geom_point(
    alpha = .5
  ) +
  scale_color_gradient(
    low = "lightblue",
    high = "dodgerblue4"
  )


## -----------------------------------------------------------------------------
ggplot(
  data = bikes,
  aes(x = temp_feel, y = n,
      color = humidity)
) +
  geom_point(
    alpha = .5
  ) +
  scale_color_gradient2(
    low = "firebrick",
    mid = "grey80",
    high = "dodgerblue4",
    midpoint = 68.3
  )


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = season_colors,
    labels = stringr::str_to_title
  )


## -----------------------------------------------------------------------------
g +
  scale_x_continuous(
    expand = expansion(mult = .05),
    breaks = seq(0, 30, by = 5), 
    labels = scales::label_number(suffix = "°C"),
    name = "Feels-like temperature"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = season_colors,
    labels = stringr::str_to_title,
    guide = guide_legend(
      override.aes = list(size = 4)
    )
  )


## -----------------------------------------------------------------------------
g + theme_grey() ## or theme_gray()


## -----------------------------------------------------------------------------
g + theme_classic()


## -----------------------------------------------------------------------------
g + theme_light()


## -----------------------------------------------------------------------------
g + theme_minimal()


## -----------------------------------------------------------------------------
g + theme_light(
  base_size = 16,
  base_family = "Sofia Sans Semi Condensed"
)


## -----------------------------------------------------------------------------
theme_set(theme_minimal())

g


## -----------------------------------------------------------------------------
theme_set(theme_minimal(
  base_size = 16,
  base_family = "Sofia Sans Semi Condensed"
))

g


## -----------------------------------------------------------------------------
ggsave(filename = "my_plot.png", plot = g)
ggsave("my_plot.png")

ggsave("my_plot.png", width = 6, height = 5, dpi = 600)
ggsave("my_plot.png", width = 6*2.54, height = 5*2.54, unit = "cm", dpi = 600)


ggsave("my_plot.png", device = agg_png)
ggsave("my_plot.pdf", device = cairo_pdf)
ggsave("my_plot.svg")


## -----------------------------------------------------------------------------
library(ggplot2)
library(dplyr)

bikes_adj <-
  readr::read_csv(
    "https://cedricscherer.com/data/london-bikes.csv",
    col_types = "Dcfffilllddddc"
  ) |>
  mutate(
    season = factor(season, labels = c("Spring", "Summer", "Autumn", "Winter")),
    day_night = stringr::str_to_title(day_night),
    is_workday = factor(is_workday, level = c(TRUE, FALSE),
                        labels = c("Workday", "Weekend or Holiday"))
  )

bikes_adj


## -----------------------------------------------------------------------------
g1 <- 
  ggplot(bikes, aes(x = temp_feel, y = n)) +
  ## point outline
  geom_point(
    color = "black", fill = "white",
    shape = 21, size = 2.8, stroke = .8
  ) +
  ## opaque point background
  geom_point(
    color = "white", size = 2.2
  ) +
  ## colored, semi-transparent points
  geom_point(
    aes(color = season),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  ## create small multiples
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y", 
    space = "free_y",
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = c(
        `TRUE` = "Workday",
        `FALSE` = "Weekend or Holiday"
      )
    )
  )

g1


## -----------------------------------------------------------------------------
g2 <- g1 +
  ## style axes
  scale_x_continuous(
    expand = expansion(mult = .02),              ## adjust horizontal padding
    breaks = 0:6*5,                              ## adjust x axis breaks
    labels = scales::label_number(suffix = "°C") ## adjust x axis labels
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)), ## adjust vertical padding
    limits = c(0, NA),                    ## include zero in all panels
    breaks = 0:5*10000,                   ## ensure equal y axis breaks
    labels = scales::label_comma()        ## add commas as big marks
  ) +
  ## custom colors + legend sizes
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), ## custom colors
    guide = guide_legend(override.aes = list(size = 5)),    ## larger legend symbols
    labels = stringr::str_to_title                          ## upper-case key labels
  ) +
  ## titles + caption
  labs(
    x = "Feels-Like Temperature", y = NULL, ## remove y axis title
    caption = "Data: Transport for London (TfL), Jan 2015–Dec 2016",
    title = "Reported TfL bike rents versus feels-like temperature in London, 2015–2016",
    color = NULL ## remove legend title
  )  +
  ## theme adjustments
  theme_light(
    base_size = 18, ## increase sizes of all text elements and widths of lines
    base_family = "Sofia Sans Semi Condensed" ## overwrite default typeface
  )

g2


## -----------------------------------------------------------------------------
## THAT'S IT FOLKS...
## -----------------------------------------------------------------------------
