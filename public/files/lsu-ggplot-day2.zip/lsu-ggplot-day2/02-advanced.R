################################################################################
#                          LS Uppsala DataViz Course                           #
# "Data Visualization with ggplot2: Advanced Adjustments & Exciting Extensions"#
#                     Cédric Scherer | November 27, 2024                       #
################################################################################


## to run all codes, install the following typefaces and restart RStudio:
## Sofia Sans Semi Condensed + Spline Sans Mono 
## The font files are located in the `fonts` folder. 

## also, make sure to install the following packages 
packages <- c(
  "ggplot2", "readr", "dplyr", "forcats", "stringr", "scales", 
  "ragg", "systemfonts", "RColorBrewer", "ggtext", "ggforce", 
  "geomtextpath", "patchwork"
)

pkgs <- c("ggplot2", "readr", "dplyr", "tibble", "tidyr", "forcats", 
          "stringr", "scales", "ragg", "systemfonts", "patchwork", "ragg", 
          "marquee", "ggtext", "ggdist", "ggridges", "ggbeeswarm", 
          "ggforce", "concavemen", "ggiraph")

install.packages(setdiff(pkgs, rownames(installed.packages())))

remotes::install_github("AllanCameron/geomtextpath")


## -----------------------------------------------------------------------------
bikes <- 
  readr::read_csv(
    "https://cedricscherer.com/data/london-bikes.csv",
    ## or: "./data/london-bikes.csv"
    col_types = "Dcfffilllddddc"
  ) |> 
  dplyr::filter(!is.na(weather_type))


## -----------------------------------------------------------------------------
library(ggplot2)

theme_set(theme_minimal(
  base_size = 14, base_family = "Sofia Sans Semi Condensed"
))


## -----------------------------------------------------------------------------
g <- 
  ggplot(
    data = bikes,
    aes(x = temp_feel, y = n,
        color = season,
        group = day_night)
  ) +
  geom_point(
    alpha = .5
  ) +
  geom_smooth(
    method = "lm",
    color = "black"
  ) +
  scale_y_continuous(
    expand = expansion(add = c(0, 1500)),
    limits = c(0, NA),
    labels = scales::label_comma()
  ) +
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), 
    labels = stringr::str_to_title,
    name = NULL,
    guide = guide_legend(override.aes = list(size = 4))
  ) +
  labs(
    x = "Feels-like temperature (°C)",
    y = "Reported bike shares",
    title = "TfL bike sharing trends",
    caption = "Data: TfL",
    color = NULL
  )

g


## -----------------------------------------------------------------------------
theme_grey


## -----------------------------------------------------------------------------
g +
  theme(
    panel.grid.minor = element_blank()
  )


## -----------------------------------------------------------------------------
g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title.position = "plot"
  )


## -----------------------------------------------------------------------------
g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title.position = "plot",
    legend.position = "top"
  )


## -----------------------------------------------------------------------------
g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title.position = "plot",
    legend.position = "none"
  )


## -----------------------------------------------------------------------------
g +
  theme(
    panel.grid.minor = element_blank(),
    plot.title.position = "plot",
    legend.position = "inside",
    legend.position.inside = c(.25, .8)
  )


## -----------------------------------------------------------------------------
theme_update(
  panel.grid.minor = element_blank(),
  plot.title.position = "plot",
  legend.position = "top"
)

g


## -----------------------------------------------------------------------------
theme_minimal


## -----------------------------------------------------------------------------
theme_custom <- function(base_size = 15, base_family = "Sofia Sans Semi Condensed", ...) { 
  theme_bw(base_size = base_size, base_family = base_family, 
           base_line_size = base_size / 30, ...) +
    theme(
      axis.ticks = element_blank(), 
      axis.text = element_text(size = rel(.8)),
      axis.title.x = element_text(hjust = 0, face = "italic", margin = margin(t = 9)),
      axis.title.y = element_text(hjust = 1, face = "italic", margin = margin(r = 9)),
      legend.text = element_text(size = rel(.8)),
      legend.background = element_blank(), 
      legend.key = element_blank(), 
      legend.position = "top", 
      panel.background = element_rect(fill = "grey97", color = NA), 
      panel.border = element_blank(), 
      panel.grid.major = element_line(color = "grey88"), 
      panel.grid.minor = element_blank(), 
      strip.background = element_blank(), 
      plot.background = element_blank(), 
      plot.title = element_text(face = "bold", size = rel(1.4), margin = margin(1, 1, 12, 1)), 
      plot.title.position = "plot",
      plot.caption.position = "plot"
    )
}


## -----------------------------------------------------------------------------
g +
  theme_custom()


## -----------------------------------------------------------------------------
g +
  theme_custom(
    base_size = 12
  ) 


## -----------------------------------------------------------------------------
g +
  theme_custom(
    base_size = 12, 
    base_family = "Georgia"
  ) 


## -----------------------------------------------------------------------------
g +
  theme_custom(
    base_size = 12, 
    base_family = "Georgia"
  ) +
  theme(
    legend.position = "right",
    panel.background = element_rect(fill = "transparent")
  )


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp)) +
  geom_point(stat = "identity") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = date, y = temp)) +
  stat_identity(geom = "point") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = weather_type)) +
  geom_bar(stat = "count") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = weather_type)) +
  stat_count(geom = "bar") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  geom_smooth(stat = "smooth") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "smooth") # default


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "pointrange")


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = temp, y = n)) +
  stat_smooth(geom = "col")


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = "mean_se", # default
    geom = "pointrange" # default
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = "mean_cl_boot",
    geom = "pointrange" # default
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  geom_boxplot() +
  stat_summary(
    fun = "mean",
    geom = "point",
    color = "#28a87d",
    size = 3
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = "mean", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y) 
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun = "mean", 
    fun.max = function(foo) mean(foo) + sd(foo), 
    fun.min = function(foo) mean(foo) - sd(foo)
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    fun.data = "mean_sdl", 
    fun.args = list(mult = 1)
  )


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = "mean",
    aes(label = after_stat(y))
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season, y = temp)
  ) +
  stat_summary(
    geom = "errorbar", 
    fun.max = function(y) mean(y) + sd(y), 
    fun.min = function(y) mean(y) - sd(y),
    width = .3
  ) +
  stat_summary(
    geom = "point",
    fun = "mean",
    size = 2
  ) +
  stat_summary(
    geom = "text",
    fun = "mean",
    aes(label = after_stat(
      sprintf("%2.1f", y)
    )),
    hjust = -.3
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        fill = n)
  ) +
  geom_tile() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d() 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d(
    geom = "tile", # default
    fun = "sum"
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d(
    geom = "tile", 
    fun = "sum", 
    color = "white", 
    linewidth = .7
  ) 


## -----------------------------------------------------------------------------
ggplot(
    bikes, 
    aes(x = season,  
        y = weather_type, 
        z = n)
  ) +
  stat_summary_2d(
    geom = "point",
    fun = "sum",
    shape = 21,
    size = 15
  ) 


## -----------------------------------------------------------------------------
ga <- 
  ggplot(bikes, 
         aes(x = temp, y = n)) +
  geom_point(
    aes(color = n > 40000),
    size = 2
  ) +
  scale_color_manual(
    values = c("grey", "firebrick"),
    guide = "none"
  )

ga


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?"
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 18,
    y = 48000,
    label = "What happened here?",
    color = "firebrick",
    size = 6,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold",
    lineheight =  .8
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = c(18, max(bikes$temp)),
    y = c(48000, 1000),
    label = c("What happened here?", "Powered by TfL"),
    color = c("firebrick", "black"),
    size = c(6, 4),
    family = c("Sofia Sans Semi Condensed", "Times"),
    fontface = c("bold", "plain"),
    hjust = c(.5, 1)
  )


## -----------------------------------------------------------------------------
## ggannotate::ggannotate(ga)


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "segment",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow()
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .25,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed",
      ends = "both"
    )
  )


## -----------------------------------------------------------------------------
ga +
  annotate(
    geom = "text",
    x = 10,
    y = 38000,
    label = "The\nhighest\ncount",
    family = "Sofia Sans Semi Condensed",
    size = 6,
    lineheight =  .8
  ) +
  annotate(
    geom = "curve",
    x = 13, 
    xend = 18.2,
    y = 38000, 
    yend = 51870,
    curvature = .8,
    angle = 130,
    arrow = arrow(
      length = unit(10, "pt"),
      type = "closed"
    )
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000)
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    color = "black",
    label.family = "Sofia Sans Semi Condensed"
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed"
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_rect(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed",
    expand = unit(8, "pt"),
    radius = unit(12, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_circle(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
ga +
  ggforce::geom_mark_hull(
    aes(label = "Outliers?",
        filter = n > 40000),
    description = "What happened on\nthese two days?",
    color = "black",
    label.family = "Sofia Sans Semi Condensed",
    expand = unit(8, "pt"),
    con.cap = unit(0, "pt"),
    label.buffer = unit(15, "pt"),
    con.type = "straight",
    label.fill = "transparent"
  )


## -----------------------------------------------------------------------------
bikes_monthly <-
  bikes |> 
  filter(year == "2016") |> 
  mutate(month = lubridate::month(date, label = TRUE)) |>
  summarize(
    n = sum(n), 
    .by = c(month, day_night)
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes_monthly,
  aes(x = month, y = n, 
      color = day_night,
      group = day_night)
) +
  geom_line(linewidth = 1) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    name = NULL
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes_monthly,
  aes(x = month, y = n, 
      color = day_night,
      group = day_night)
) +
  geom_line(linewidth = 1) +
  geom_text(
    data = filter(bikes_monthly, month == "Jul"),
    aes(label = day_night),
    family = "Sofia Sans Semi Condensed",
    fontface = "bold",
    vjust = -.5,
    hjust = 0
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
ggplot(
  bikes_monthly,
  aes(x = month, y = n, 
      color = day_night,
      group = day_night)
) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  )


## -----------------------------------------------------------------------------
bikes_monthly |>
  mutate(day_night = if_else(
    day_night == "day", 
    "Day period (6am-6pm)", 
    "Night period (6pm-6am)"
  )) |> 
  ggplot(aes(x = month, y = n, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    hjust = .05,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold"
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  ) 


## -----------------------------------------------------------------------------
bikes_monthly |>
  mutate(day_night = if_else(
    day_night == "day", 
    "Day period (6am-6pm)", 
    "Night period (6pm-6am)"
  )) |> 
  ggplot(aes(x = month, y = n, 
             color = day_night,
             group = day_night)) +
  geomtextpath::geom_textline(
    aes(label = day_night),
    linewidth = 1,
    vjust = -.5, 
    hjust = .05,
    family = "Sofia Sans Semi Condensed",
    fontface = "bold",
    straight = TRUE
  ) +
  scale_color_manual(
    values = c("#FFA200", "#757BC7"),
    guide = "none"
  ) 


## -----------------------------------------------------------------------------
library(systemfonts)

match_font("Sofia Sans", bold = TRUE)


## -----------------------------------------------------------------------------
system_fonts()


## -----------------------------------------------------------------------------
system_fonts() |>
  filter(stringr::str_detect(family, "Sofia Sans")) |>
  select(family) |>
  unique() |> 
  arrange(family)


## -----------------------------------------------------------------------------
g +
  theme_minimal(
    base_family = "Sofia Sans Semi Condensed",
    base_size = 13
  )


## -----------------------------------------------------------------------------
system_fonts() |>
  filter(family == "Sofia Sans Semi Condensed") |>
  select(name) |>
  arrange(name)


## -----------------------------------------------------------------------------
register_variant(
  name = "Sofia Sans Semi Condensed Heavy",
  family = "Sofia Sans Semi Condensed",
  weight = "heavy"
)


## -----------------------------------------------------------------------------
g + 
  theme_minimal(
    base_family = "Sofia Sans Semi Condensed Heavy",
    base_size = 13
  )


## -----------------------------------------------------------------------------
register_variant(
  name = "Spline Sans Tabular",
  family = "Spline Sans",
  weight = "normal",
  features = font_feature(numbers = "tabular")
)


## -----------------------------------------------------------------------------
g +
  ggtitle("**TfL bike sharing trends by *period of the day***")


## -----------------------------------------------------------------------------
g +
  ggtitle("**TfL bike sharing trends by *period of the day***") +
  theme(
    plot.title = ggtext::element_markdown()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends during <b style='color:#FFA200;'>day</b> and <b style='color:#757BC7;'>night</b>") +
  theme(
    plot.title = ggtext::element_markdown()
  )


## -----------------------------------------------------------------------------
g +
  ggtitle("<i style='font-family:times;font-size:30pt;'>TfL</i> bike sharing trends during <b style='color:#FFA200;'>day</b> and <b style='color:#757BC7;'>night</b>") +
  theme(
    plot.title = 
      ggtext::element_textbox_simple(
        margin = margin(t = 12, b = 12),
        padding = margin(rep(12, 4)),
        fill = "grey90",
        box.colour = "grey30",
        linetype = "13",
        r = unit(9, "pt"),
        halign = .5,
        lineheight = 1
      )
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_richtext(
    data = data.frame(
      temp_feel = c(5, 25),
      n = c(40000, 5000),
      day_night = "day",
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**")
    ),
    aes(label = lab),
    color = "black"
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_richtext(
    data = data.frame(
      temp_feel = c(5, 25),
      n = c(40000, 5000),
      day_night = "day",
      lab = c("*Note **1***", 
              "<b style='color:red;'>Note</b> **2**"),
      angle = c(35, 310)
    ),
    aes(label = lab,
        angle = angle),
    color = "black"
  )


## -----------------------------------------------------------------------------
g +
  ggtext::geom_textbox(
    data = data.frame(
      temp_feel = 10,
      n = 40000,
      day_night = "day",
      lab = "Lorem ipsum dolor sit amet, **consectetur adipiscing elit**, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud <i style='color:red;'>exercitation</i> ullamco laboris nisi ut aliquip ex ea commodo consequat."
    ),
    aes(label = lab),
    color = "black",
    size = 3,
    halign = .5
  )


## -----------------------------------------------------------------------------
g +
  marquee::geom_marquee(
    data = filter(bikes, n > 40000),
    aes(label = paste0("{.orange **", date, "**} was a **Strike Day**")),
    color = "black",
    vjust = 1.3
  ) +
  coord_cartesian(clip = "off")


## -----------------------------------------------------------------------------
md <- 
  "## Bike Rents in {.red London}
The visualization shows the _number of bikes_ versus _average temperature_."

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )


## -----------------------------------------------------------------------------
md <- 
  "One can even add code chunks:

    text <- \"markdown **text**\"
    marquee_grob(text)

... and even lists:

1. this
1. is
1. awesome!
"

g +
  ggtitle(md) + 
  theme(
    plot.title = marquee::element_marquee(
      width = unit(1, "npc")
    )
  )


## -----------------------------------------------------------------------------
logo <- "![](img/tfl.jpg)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      width = unit(1.15, "npc")
    )
  )


## -----------------------------------------------------------------------------
logo <- "Powered by TfL Open Data ![](img/tfl.png)"

g +
  labs(caption = logo) + 
  theme(
    plot.caption = marquee::element_marquee(
      size = 20, margin = margin(20, 0, 0, 0)
    )
  )


## -----------------------------------------------------------------------------
bikes_day <- filter(bikes, day_night == "day")

ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_boxplot()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_violin()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  geom_violin() +
  geom_boxplot(width = .2)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(priority = "descending")


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(side = -1)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_beeswarm(method = "hex", size = 1.5, cex = 2)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_quasirandom()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggbeeswarm::geom_quasirandom(method = "smiley")


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_eye()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye() ## default: `.width = c(.66, .95)`


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = .5)  +
  ggtitle("stat_halfeye(.width = .5)") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = c(0, 1)) +
  ggtitle("stat_halfeye(.width = c(0, 1))") +
  theme(plot.title = element_text(family = "Spline Sans Mono", face = "bold"))


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_halfeye(.width = c(0, 1), adjust = .5, shape = 23, point_size = 5)


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = season, y = humidity, fill = day_night)) +
  ggdist::stat_halfeye(.width = 0, adjust = .5, slab_alpha = .5, shape = 21) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval()


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25, linewidth = 10) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_dots(position = position_nudge(x = .05), scale = .8) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = season, y = humidity)) +
  ggdist::stat_interval(.width = 1:4*.25) +
  ggdist::stat_halfeye(.width = 0, color = "white", position = position_nudge(x = .025)) +
  scale_color_viridis_d(option = "mako", direction = -1, end = .9)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = humidity, y = season)) +
  ggridges::geom_density_ridges()


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = humidity, y = season, fill = day_night)) +
  ggridges::geom_density_ridges(alpha = .5)


## -----------------------------------------------------------------------------
ggplot(bikes, aes(x = humidity, y = season, fill = day_night)) +
  ggridges::geom_density_ridges(alpha = .5, color = "white", scale = 1.5) +
  scale_fill_manual(values = c("#EFAC00", "#9C55E3"), name = NULL)


## -----------------------------------------------------------------------------
ggplot(bikes_day, aes(x = humidity, y = season, fill = stat(x))) +
  ggridges::geom_density_ridges_gradient(color = "white", scale = 1.5) +
  scale_fill_gradient(low = "#FFCE52", high = "#663399", guide = "none")


## -----------------------------------------------------------------------------
theme_set(theme_minimal(base_size = 18, base_family = "Pally"))
theme_update(
  text = element_text(family = "Pally"),
  panel.grid = element_blank(),
  axis.text = element_text(color = "grey50", size = 12),
  axis.title = element_text(color = "grey40", face = "bold"),
  axis.title.x = element_text(margin = margin(t = 12)),
  axis.title.y = element_text(margin = margin(r = 12)),
  axis.line = element_line(color = "grey80", linewidth = .4),
  legend.text = element_text(color = "grey50", size = 12),
  plot.tag = element_text(size = 40, margin = margin(b = 15)),
  plot.background = element_rect(fill = "white", color = "white")
)

bikes_sorted <-
  bikes |>
  filter(!is.na(weather_type)) |>
  group_by(weather_type) |>
  mutate(sum = sum(n)) |>
  ungroup() |>
  mutate(
    weather_type = forcats::fct_reorder(
      stringr::str_to_title(stringr::str_wrap(weather_type, 5)), sum
    )
  )

p1 <- 
  ggplot(
    bikes_sorted,
    aes(x = weather_type, y = n, color = weather_type)
  ) +
  geom_hline(yintercept = 0, color = "grey80", linewidth = .4) +
  stat_summary(
    geom = "point", fun = "sum", size = 12
  ) +
  stat_summary(
    geom = "linerange", ymin = 0, fun.max = function(y) sum(y),
    size = 2, show.legend = FALSE
  ) +
  coord_flip(ylim = c(0, NA), clip = "off") +
  scale_y_continuous(
    expand = c(0, 0), limits = c(0, 8500000),
    labels = scales::comma_format(scale = .0001, suffix = "K")
  ) +
  scale_color_viridis_d(
    option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
    guide = guide_legend(override.aes = list(size = 7))
  ) +
  labs(
    x = NULL, y = "Sum of reported bike shares", tag = "P1",
  ) +
  theme(
    axis.line.y = element_blank(),
    axis.text.y = element_text(family = "Pally", color = "grey50", face = "bold",
                               margin = margin(r = 15), lineheight = .9)
  )

p1


## -----------------------------------------------------------------------------
p2 <- 
  bikes_sorted |>
  filter(season == "winter", is_weekend == TRUE, day_night == "night") |>
  group_by(weather_type, .drop = FALSE) |>
  mutate(id = row_number()) |>
  ggplot(
    aes(x = weather_type, y = id, color = weather_type)
  ) +
  geom_point(size = 4.5) +
  scale_color_viridis_d(
    option = "magma", direction = -1, begin = .1, end = .9, name = NULL,
    guide = guide_legend(override.aes = list(size = 7))
  ) +
  labs(
    x = NULL, y = "Reported bike shares on\nweekend winter nights", tag = "P2",
  ) +
  coord_cartesian(ylim = c(.5, NA), clip = "off")

p2


## -----------------------------------------------------------------------------
my_colors <- c("#cc0000", "#000080")

p3 <- 
  bikes |>
  group_by(week = lubridate::week(date), day_night, year) |>
  summarize(n = sum(n)) |>
  group_by(week, day_night) |>
  mutate(avg = mean(n)) |>
  ggplot(aes(x = week, y = n, group = interaction(day_night, year))) +
  geom_line(color = "grey65", linewidth = 1) +
  geom_line(aes(y = avg, color = day_night), stat = "unique", linewidth = 1.7) +
  annotate(
    geom = "text", label = c("Day", "Night"), color = my_colors,
    x = c(5, 18), y = c(125000, 29000), size = 8, fontface = "bold", family = "Pally"
  ) +
  scale_x_continuous(breaks = c(1, 1:10*5)) +
  scale_y_continuous(labels = scales::comma) +
  scale_color_manual(values = my_colors, guide = "none") +
  labs(
    x = "Week of the Year", y = "Reported bike shares\n(cumulative # per week)", tag = "P3",
  )

p3


## -----------------------------------------------------------------------------
library(patchwork)
(p1 + p2) / p3


## -----------------------------------------------------------------------------
(p1 + p2) / p3 + plot_layout(guides = "collect")


## -----------------------------------------------------------------------------
((p1 + p2) / p3 & theme(legend.justification = "top")) + plot_layout(guides = "collect")


## -----------------------------------------------------------------------------
((p1 + p2) / p3 & theme(legend.position = "none")) +
  plot_layout(heights = c(.2, .1), widths = c(2, 1))


## -----------------------------------------------------------------------------
picasso <- "
AAAAAA#BBBB
CCCCCCCCC##
CCCCCCCCC##"
(p1 + p2 + p3 & theme(legend.position = "none")) + plot_layout(design = picasso)


## -----------------------------------------------------------------------------
pl1 <- p1 + labs(tag = NULL, title = "Plot One") + theme(legend.position = "none")
pl2 <- p2 + labs(tag = NULL, title = "Plot Two") + theme(legend.position = "none")
pl3 <- p3 + labs(tag = NULL, title = "Plot Three") + theme(legend.position = "none")


## -----------------------------------------------------------------------------
(pl1 + pl2) / pl3 +
  plot_annotation(
    tag_levels = "1", tag_prefix = "P", 
    title = "An overarching title for all 3 plots, placed on the very top while all other titles are sitting below the tags."
  )


## -----------------------------------------------------------------------------
pl1 + inset_element(pl2, l = .6, b = .1, r = 1, t = .6)


## -----------------------------------------------------------------------------
pl1 + inset_element(pl2, l = .6, b = 0, r = 1, t = .5, align_to = 'full')


## -----------------------------------------------------------------------------
theme_set(theme_minimal(
  base_size = 14, base_family = "Sofia Sans Semi Condensed"
))

theme_update(
  panel.grid.minor = element_blank(),
  plot.title.position = "plot",
  legend.position = "top"
)


## -----------------------------------------------------------------------------
g2 <- 
  ggplot(bikes, aes(x = temp, y = n, color = day_night)) +
  geom_point_interactive(aes(tooltip = date, data_id = date), size = 3, alpha = .7) +
  ggforce::geom_mark_hull(
    aes(label = "Tube Network Strikes 2015", filter = n > 40000),
    description = "Commuters had to deal with severe disruptions in public transport on July 9 and August 6",
    color = "black", label.family = "Sofia Sans Semi Condensed", label.fontsize = c(18, 14)
  ) +
  coord_cartesian(clip = "off") +
  scale_color_manual(values = c("#EFAC00", "#9C55E3"), guide = "none") +
  labs(x = "Feels-like temperature (°C)", y = "Reported bike shares") +
  ggtitle("TfL bike sharing trends by *<b style='color:#B48200;'>day</b>* and *<b style='color:#663399;'>night</b>*") +
  theme(plot.title = ggtext::element_markdown(), plot.title.position = "plot") 


## -----------------------------------------------------------------------------
girafe(
  ggobj = g2, width_svg = 9, height_svg = 5.5,
  options = list(
    opts_tooltip(use_fill = TRUE, css = "font-size:18pt;font-weight:600;color:white;padding:7px;font-family:asap;"), 
    opts_hover(css = "fill:black;stroke:black;stroke-width:8px;opacity:1;"),
    opts_hover_inv(css = "opacity:0.3;"),
    opts_toolbar(position = "bottomleft"),
    opts_zoom(min = 1, max = 4)
  )
)


## -----------------------------------------------------------------------------
g1 <- 
  ggplot(bikes, aes(x = temp_feel, y = n, color = season)) +
  ## point outline
  geom_point_interactive(
    aes(data_id = date),
    color = "black", fill = "white",
    shape = 21, size = 2.8, stroke = .8
  ) +
  ## opaque point background
  geom_point_interactive(
    aes(data_id = date),
    color = "white", size = 2.2
  ) +
  ## colored, semi-transparent points
  geom_point_interactive(
    aes(data_id = date, 
        tooltip = paste0(format(date, format = "%B %d, %Y"), "<br><b style='font-size:10pt;font-weight:900;'>", scales::comma(n), " bikes | ", sprintf("%1.1f", temp_feel), "°C</b>")),
    size = 2.2, alpha = .55
  ) +
  geom_smooth(
    aes(group = day_night), method = "lm", color = "black"
  ) +
  ## add call-out
  ggforce::geom_mark_hull(
    aes(label = "Tube Network Strikes 2015",
        filter = n > 40000),
    description = "Severe disruptions in public transport on July 9 and August 6",
    color = "black", label.fontsize = c(16, 13),
    label.family = "Sofia Sans Semi Condensed"
  )  +
  ## create small multiples
  facet_grid(
    day_night ~ is_workday,
    scales = "free_y", 
    space = "free_y",
    labeller = labeller(
      day_night = stringr::str_to_title,
      is_workday = c(
        `TRUE` = "Workday",
        `FALSE` = "Weekend or Holiday"
      )
    )
  )

g1


## -----------------------------------------------------------------------------
library(ggiraph)

girafe(
  ggobj = g1,
  width_svg = 14,
  height_svg = 8.3
)


## -----------------------------------------------------------------------------
library(systemfonts)
 
register_variant(
  name = "Sofia Sans Semi Condensed Black",
  family = "Sofia Sans Semi Condensed",
  weight = "heavy"
)


## -----------------------------------------------------------------------------
g2 <- g1 +
  ## style axes
  scale_x_continuous(
    expand = expansion(mult = .02),              ## adjust horizontal padding
    breaks = 0:6*5,                              ## adjust x axis breaks
    limits = c(0, NA),                           ## include zero baseline
    labels = scales::label_number(suffix = "°C") ## adjust x axis labels
  ) +
  scale_y_continuous(
    expand = expansion(mult = 0, add = c(0, 5000)),  ## adjust vertical padding
    limits = c(0, NA),                               ## include zero in all panels
    breaks = 0:5*10000,                              ## ensure equal y axis breaks
    labels = scales::label_comma()                   ## add commas as big marks
  ) +
  ## custom colors + legend sizes
  scale_color_manual(
    values = c("#3c89d9", "#1ec99b", "#F7B01B", "#a26e7c"), ## custom colors
    guide = guide_legend(override.aes = list(size = 5)),    ## larger legend symbols
    labels = stringr::str_to_title                          ## upper-case key labels
  ) +
  ## titles + caption
  labs(
    x = "Feels-Like Temperature", y = NULL, ## remove y axis title
    caption = "Data: Transport for London (TfL), Jan 2015–Dec 2016",
    title = "Reported TfL bike rents versus feels-like temperature in London, 2015–2016",
    color = NULL ## remove legend title
  )  +
  ## theme adjustments
  theme_light(
    base_size = 18, ## increase sizes of all text elements and widths of lines
    base_family = "Sofia Sans Semi Condensed" ## overwrite default typeface
  ) +
  ## more theme adjustments
  theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = ggtext::element_textbox_simple(
      family = "Sofia Sans Semi Condensed Black", 
      margin = margin(t = 12, b = 12),
      padding = margin(rep(12, 4)),
      fill = "grey90",
      r = unit(9, "pt"),
      halign = .5,
      size = rel(1.6),
      lineheight = .95
    ),
    axis.title.x = element_text(hjust = 0, color = "grey30", margin = margin(t = 12)),
    strip.text = element_text(face = "bold", size = rel(1.15)),
    panel.grid.major.x = element_blank(),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(1.2, "lines"),
    legend.position = "top",
    legend.text = element_text(size = rel(1)),
    ## for fitting my slide background
    legend.key = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    legend.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8"),
    plot.background = element_rect(color = "#f8f8f8", fill = "#f8f8f8")
  )


## -----------------------------------------------------------------------------
girafe(
  ggobj = g2,
  width_svg = 14,
  height_svg = 8.3,
  options = list(
    opts_hover(css = "stroke-width:5"),
    opts_hover_inv(css = "opacity:0.1;"),
    opts_tooltip(use_fill = TRUE, css = "stroke-width:5;opacity:1;font-size:14pt;font-weight:400;color:black;border-radius:4px;padding:7px;font-family:sofia sans semi condensed;"),
    opts_toolbar(position = "bottomleft")
  )
)



## -----------------------------------------------------------------------------
## THAT'S IT FOLKS...
## -----------------------------------------------------------------------------



## DATA + TITLES FOR EXERCISES

## -----------------------------------------------------------------------------
movies <- data.frame(
  movie = c("Star Wars: The Last Jedi", "Jumanji: Welcome To The Jungle", "Pitch Perfect 3", "Greatest Showman", "Ferdinand", "Coco"),
  gross_millions = c(66.814, 66.273, 21.676, 20.907, 14.852, 10.083)
)


## -----------------------------------------------------------------------------
news <- 
  tibble::tribble(
    ~year, ~Television, ~Newspaper, ~Internet, ~Radio,
    2001,  74,          45,         13,        18,
    2002,  82,          42,         14,        21,
    2003,  80,          50,         18,        20, 
    2004,  74,          46,         24,        21, 
    2005,  73,          36,         20,        16, 
    2006,  72,          36,         24,        14, 
    2007,  74,          34,         24,        13, 
    2008,  70,          35,         40,        18, 
    2009,  70,          32,         35,        17, 
    2010,  66,          31,         41,        16
  ) |> 
  tidyr::pivot_longer(
    cols = -c(year), names_to = "media", values_to = "percentage"
  ) |> 
  mutate(media = forcats::fct_inorder(media))

title <- "An increasing proportion cite the <b style='color:#d4580a;'>internet</b> as their primary news source."
subtitle <- 'Responses to the question “where do you get most of your news about national and international issues?”'
caption <- 'Data source: Pew Research Center\nFigures sum to more than 100% because respondents could volunteer up to two main sources.'

